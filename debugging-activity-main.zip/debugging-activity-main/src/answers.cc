#include <utilities.hpp>
std::string ClassesToTake(std::vector<std::string> classes, int current_class) {
  std::string need_to_take = "";
  for(size_t i = 0; i < classes.size(); i++) {
    int class_number = std::stoi(classes.at(i).substr(3,3));

    if(class_number > current_class) {
      need_to_take += std::to_string(class_number);
      if(i != classes.size() -1) {
        need_to_take += ", ";
      }
    }
  }

  return need_to_take;
}

/*
  CalculateTuition should return the result of
  multiplying the number of courses by the cost per course.
*/
size_t CalculateTuition(size_t course_count) {
  const size_t kCostPerCourse = 1000;
  std::cout << "Cost Per Course: " << kCostPerCourse << std::endl;
  return course_count * kCostPerCourse;
}

/* 
  CanPayTuition calculates the tuition cost based on the 
  number of courses in the courses vector and returns 
  whether the student can pay tuition based on the passed in
  money value.
*/
bool CanPayTuition(std::vector<std::string> courses, size_t money) {
  std::cout << "Calculating";
  std::cout << ".";
  std::cout << ".";
  std::cout << "." << std::endl;
  std::cout << "Done!" << std::endl;
  return money >= CalculateTuition(courses.size());
}


//------------------------------------------------------------------------------------------
//ANSWER KEY:


