#include <iostream>

#include "utilities.hpp"

int main() {
  std::vector<std::string> my_classes = {"CS 124", "CS 128", "CS 225", "CS 340", "CS 374", "CS 420"};

  std::cout << "Example 1 Expected Output: 1" << std::endl;
  size_t first_wallet = 3e7;
  size_t second_wallet = 10;
  bool example_one = CanPayTuition(my_classes, first_wallet);
  std::cout << example_one << std::endl;
  std::cout << std::endl;

  std::cout << "Example 2 Expected Output: 0" << std::endl;
  bool example_two = CanPayTuition(my_classes, second_wallet);
  std::cout << example_two << std::endl;
  std::cout << std::endl;

  std::cout << "Example 3 Expected Output: " << "\"You still need to take these classes: 225, 340, 374, 420\"" << std::endl;
  std::cout << "You still need to take these classes: " << ClassesToTake(my_classes, 128) << std::endl;
  std::cout << std::endl;

  
}