#ifndef UTILITIES_HPP
#define UTILITIES_HPP

#include <string>
#include <vector>
#include <iostream>

std::string ClassesToTake(std::vector<std::string> classes, int current_class);

bool CanPayTuition(std::vector<std::string> courses, size_t money);
#endif